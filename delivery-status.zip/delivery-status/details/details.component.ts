import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { ScrapReasonViewModel } from 'src/app/models/scrap.reason.model.';
import { DeliveryStatusService } from '../delivery-status.service';
import { BitInformationViewModel } from '../models/bit-information-view-model';
import { DeliveryStatusViewModel } from '../models/delivery-status-view-models';
import { EquipmentInfo } from '../models/equipment-info';
import { LocationViewModel } from '../models/location-view-model';
import { ShippingInformation } from '../models/shiping-information';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html'
})
export class DetailsComponent implements OnInit {

  shippingInformation: ShippingInformation = {} as ShippingInformation;
  bitInformation: EquipmentInfo = {} as EquipmentInfo;
  deliveryStatusViewModel: DeliveryStatusViewModel = {} as DeliveryStatusViewModel;
  bitInformationViewModel: BitInformationViewModel = {} as BitInformationViewModel;
  locationViewModel: LocationViewModel = {} as LocationViewModel;
  scrapReasons: ScrapReasonViewModel[] = [];
  deliveryStatusForm: FormGroup = new FormGroup({});
  
  validateForm!: FormGroup;

  loading = false;
  constructor(
    private appService: AppService,
    private deliveryStatusService: DeliveryStatusService,
    private router: Router,
    private fb: FormBuilder) { }

  ngOnInit(): void {
    this.validateForm = this.fb.group({
      formLayout: ['horizontal'],
      fieldA: [null, [Validators.required]],
      filedB: [null, [Validators.required]]
    });

    
    this.createForm();
    const docNo = this.router.url.split('/')[3];
    if (docNo !== undefined && docNo !== '') {

      this.deliveryStatusService.getShippingInformation().subscribe(m => this.shippingInformation = m, e => console.log(e));

      this.deliveryStatusService.getRepaireEntry(docNo).subscribe((m) => {
        this.deliveryStatusService.getBitInformation(m.amiIbMaterial).subscribe(m => this.bitInformationViewModel = m, e => console.log(e));
        this.deliveryStatusViewModel = m;
        this.deliveryStatusService.getDeliveryStats(m.amiIbSerial).subscribe(m => {
          this.deliveryStatusService.getValidateManufacture(m.manufCode).subscribe(m => this.locationViewModel = m, e => console.log(e));
          this.bitInformation = m;
          this.pathForm();
        }, e => console.log(e));
      }, e => console.log(e));

      this.updateScrapReasons();
    } else {
      this.router.navigate(["/delivery-status/inbound"]);
    }

  }

  
  pathForm() {
    this.deliveryStatusForm.patchValue({
      shippingOrigin: this.deliveryStatusViewModel.amiIbLoc,
      repairFacility: this.deliveryStatusViewModel.amiIbPriority,
      returnDestination: this.deliveryStatusViewModel.amiIbRedirLoc,
    })
  }

  createForm() {
    this.deliveryStatusForm = this.fb.group({
      shippingOrigin: [''],
      repairFacility: [''],
      returnDestination: [''],
      materialXferDate: [''],
      materialXferNo: [''],
      shippingDate: [''],
      requestedDate: [''],
      makePriririty: [false],
      retroFit: [false],
      requestScrap: [false],
      scrapReason: [''],
      fieldNote: ['']
    });
  }

  updateScrapReasons() {
    this.appService.getScrapReasons().subscribe(m => this.scrapReasons = m, e => console.log(e))
  }

  submitForm(): void {
    if (this.validateForm.valid) {
      console.log('submit', this.validateForm.value);
    } else {
      Object.values(this.validateForm.controls).forEach(control => {
        if (control.invalid) {
          control.markAsDirty();
          control.updateValueAndValidity({ onlySelf: true });
        }
      });
    }
  }

  get isHorizontal(): boolean {
    return this.validateForm.controls.formLayout?.value === 'horizontal';
  }

}