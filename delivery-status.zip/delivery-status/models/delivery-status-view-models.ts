export interface DeliveryStatusViewModel {
  amiIbSerial: string;
  amiIbMaterial: string;
  amiIbComType: string;
  amiIbDesc: string;
  amiRequestDate: Date;
  origin: string;
  amiIbShpped: boolean;
  amiIbDocNo: number;
  
  amiIbWrkord: string;
  amiIbMatType: string;
  amiIbSeries: string;
  amiIbCntry: string;
  amiIbSize: string;
  amiIbWoText: string;
  amiIbPriority: string;
  amiIbRetro: string;
  amiIbRetroNo: string;
  amiIbXferLoc: string;

  // for delivery status
  amiIbMtDate: Date;
  amiIbMtNumber: string;
  amiIbShipped: Date;

  amiIbLoc: string;
  amiIbPlant: string;
  amiIbRedirLoc: string,
}
