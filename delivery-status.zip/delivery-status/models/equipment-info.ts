export interface EquipmentInfo {
    equipmentID: string;
    materialNumber: string;
    serialNumber: string;
    size: number;
    manufCode: string;
    manufName: string;
    vendorCode: string;
    vendorName: string;
    workCenter: string;
    workCenterName: string;
    workCenterPlantID: string;
    costCenter: string;
    categoryCode: string;
    materialTypeCode: string;
    commonTypeCode: string;
    operationStartDate: Date | string;
    validityStartDate: Date | string;
    description: string;
    class: AssetClass;
    category: AssetCategory;
}

export enum AssetCategory {
    fixedCutter_Matrix = 1,
    fixedCutter_Steel = 2
}

export enum AssetClass {
    rollerCone = 10107,
    coreHeads = 10116,
    fixedCutter = 10120,
    downHoleTools = 10121,
    other = 10108
}

export interface PartyCodes {
    manufacture: string;
    vendor: string;
}
