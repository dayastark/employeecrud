export interface LocationViewModel {
  plantCode: string;
  plantName: string;
}
