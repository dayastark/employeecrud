import { LocationViewModel } from "./location-view-model";

export interface ShippingInformation {
  omcLocations: LocationViewModel[];
  repairFacilities: LocationViewModel[];
  omcReturnLocations: LocationViewModel[];
}

