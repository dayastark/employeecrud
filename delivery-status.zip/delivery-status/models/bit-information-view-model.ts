export interface BitInformationViewModel {
  bitSize: string;
  bitType: string;
  bitSeries: string;
  iadcCode: string;
  material: string;
  numBlades: string;
  cutterType: string;
  powder: string;
  stdNoz: string;
  gageLength: string;
  shankDia: string;
  shipWeight: string;
  active: string;
  replacedBy: string;
}
