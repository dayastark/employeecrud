import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { environment } from 'src/environments/environment';
import { BitInformationViewModel } from './models/bit-information-view-model';
import { DeliveryStatusViewModel } from './models/delivery-status-view-models';
import { EquipmentInfo } from './models/equipment-info';
import { LocationViewModel } from './models/location-view-model';
import { ShippingInformation } from './models/shiping-information';

@Injectable({
  providedIn: 'root'
})
export class DeliveryStatusService {
  
  constructor(private http: HttpClient) {
  }

  getInBound(plantCode: string) {
    return this.http.get<DeliveryStatusViewModel[]>(`${environment.baseUrl}/DeliveryStatus/GetInBound/${plantCode}`);
  }

  getOutBound(plantCode: string) {
    return this.http.get<DeliveryStatusViewModel[]>(`${environment.baseUrl}/DeliveryStatus/GetOutBound/${plantCode}`);
  }

  getDeliveryStats(serialNo: string) {
    return this.http.get<EquipmentInfo>(`${environment.baseUrl}/DeliveryStatus/GetBitInformation/${serialNo}`);
  }

  getShippingInformation() {
    return this.http.get<ShippingInformation>(`${environment.baseUrl}/DeliveryStatus/GetShippingInformation`);
  }

  getRepaireEntry(documentNo: string) {
    return this.http.get<DeliveryStatusViewModel>(`${environment.baseUrl}/DeliveryStatus/GetRepairEntry/${documentNo}`);
  }

  getBitInformation(materialNo: string) {
    return this.http.get<BitInformationViewModel>(`${environment.baseUrl}/DeliveryStatus/GetBitInformationByMaterialNo/${materialNo}`);
  }

  getValidateManufacture(plantCode: string) {
    return this.http.get<LocationViewModel>(`${environment.baseUrl}/DeliveryStatus/GetValidateManufacture/${plantCode}`);
  }
}
