import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NzTableSize } from 'ng-zorro-antd/table';
import { AppService } from 'src/app/app.service';
import { DeliveryStatusService } from '../delivery-status.service';
import { DeliveryStatusViewModel } from '../models/delivery-status-view-models';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html'
})
export class IndexComponent implements OnInit {
  loading = false;
  inbounds: DeliveryStatusViewModel[] = [];
  outbounds: DeliveryStatusViewModel[] = [];
  size: NzTableSize = 'small';
  
  constructor(
    private deliveryStatusService: DeliveryStatusService,
    private router: Router,
    private appService: AppService) { }

  ngOnInit(): void {
    const plantCode = this.appService.getPlantCode();
    if (plantCode) {
      this.loading = true;
      this.deliveryStatusService.getInBound(plantCode).subscribe(data => {
        this.inbounds = data;
        this.loading = false;
      }, e => {
        this.loading = false;
      });
      this.loading = true;
      this.deliveryStatusService.getOutBound(plantCode).subscribe(data => {
        this.outbounds = data;
        this.loading = false;
      }, e => {
        this.loading = false;
      });
    }
  }


  exportAsXLSX(exportType: string): void {
    if (exportType === 'inbounds') {
      this.appService.exportAsExcelFile(this.inbounds, exportType);
    }
    if (exportType == 'outbounds') {
      this.appService.exportAsExcelFile(this.outbounds, exportType);
    }
  }


  navigateDetail(model: DeliveryStatusViewModel) {
    this.router.navigate(['delivery-status/details', model.amiIbDocNo])
  }

}
