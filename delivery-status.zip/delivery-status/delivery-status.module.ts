import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IndexComponent } from './index/index.component';
import { DetailsComponent } from './details/details.component';
import { DeliveryStatusRoutingModule } from './delivery-status-routing.module';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [
    IndexComponent,
    DetailsComponent
  ],
  imports: [
    CommonModule,
    DeliveryStatusRoutingModule,
    SharedModule
  ]
})
export class DeliveryStatusModule { }
